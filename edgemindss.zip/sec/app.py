from flask import Flask, jsonify, send_from_directory
import serial
import time

app = Flask(__name__)

PORT = "COM3"
BAUD = 9600

ser = None

# ---------------- CONNECT ----------------
def connect():
    global ser
    try:
        ser = serial.Serial(PORT, BAUD, timeout=1)
        time.sleep(2)
        print("✅ Arduino Connected")
    except Exception as e:
        print("❌ Connection Failed:", e)
        ser = None

connect()

# ---------------- BUFFER ----------------
sound_buffer = []
current_buffer = []

# ---------------- ANALYSIS ----------------
def analyze(sound, vibration, current):
    global sound_buffer, current_buffer

    # store last 5 values
    sound_buffer.append(sound)
    current_buffer.append(current)

    if len(sound_buffer) > 5:
        sound_buffer.pop(0)
        current_buffer.pop(0)

    avg_sound = sum(sound_buffer) / len(sound_buffer)
    avg_current = sum(current_buffer) / len(current_buffer)

    # ---------------- RULES ----------------

    # 🟡 Idle
    if current < 200:
        return "🟡 Idle", "Motor OFF"

    # 🚨 HARD anomaly (VERY RELIABLE)
    if vibration == 1:
        return "🚨 Anomaly Detected", "Physical disturbance detected"

    # 🚨 Sudden sound spike
    if abs(sound - avg_sound) > 35:
        return "🚨 Anomaly Detected", "Abnormal sound spike"

    # 🚨 Current overload (based on your data)
    if current > avg_current + 30:
        return "🚨 Anomaly Detected", "Motor load increased"

    # ✅ Normal
    return "✅ Normal", "Machine stable"


# ---------------- ROUTES ----------------
@app.route("/")
def home():
    return send_from_directory(".", "frontend.html")


@app.route("/arduino")
def get_data():
    global ser

    try:
        if ser is None:
            connect()

        if ser and ser.in_waiting:
            line = ser.readline().decode().strip()
            print("RAW:", line)

            parts = line.split(",")

            if len(parts) == 3:
                sound = int(parts[0])
                vibration = int(parts[1])
                current = float(parts[2])

                prediction, cyber = analyze(sound, vibration, current)

                return jsonify({
                    "sound": sound,
                    "vibration": vibration,
                    "current": round(current, 2),
                    "prediction": prediction,
                    "cyber": cyber
                })

        return jsonify({
            "sound": 0,
            "vibration": 0,
            "current": 0,
            "prediction": "Waiting...",
            "cyber": ""
        })

    except Exception as e:
        print("ERROR:", e)
        return jsonify({
            "sound": 0,
            "vibration": 0,
            "current": 0,
            "prediction": "Error",
            "cyber": str(e)
        })


# ---------------- RUN ----------------
if __name__ == "__main__":
    app.run(debug=False)